﻿using System.Diagnostics;

namespace P03_Terminverwaltung
{
    internal static class Utils
    {
        //  Verwendet binäre Suche mit list.LowerBound(...), daher nur für sortierte List zulässig.
        //  Elemente im Range sind größer oder gleich lowerBoundKey ('inklusive')
        //  und kleiner als upperBoundKey ('exklusive').
        public static (int Begin, int End) RangeQuery<T>(this List<T> list, T lowerBoundKey, T upperBoundKey, IComparer<T>? comparer = null)
        {
            return (LowerBound(list, lowerBoundKey, comparer), LowerBound(list, upperBoundKey, comparer));
        }

        //  Verwendet binäre Suche mit list.LowerBound(...), daher nur für sortierte List zulässig.
        //  Elemente im Range sind größer oder gleich lowerBoundKey ('inklusive')
        //  und kleiner als upperBoundKey ('exklusive').
        public static (int Begin, int End) RangeQuery<T, K>(this List<T> list, K lowerBoundKey, K upperBoundKey, Func<T, K> transform, IComparer<K>? comparer = null)
        {
            return (LowerBound(list, lowerBoundKey, transform, comparer), LowerBound(list, upperBoundKey, transform, comparer));
        }

        public static (int LowerBound, int UpperBound) EqualRange<T, K>(this List<T> list, K key, Func<T, K> transform, IComparer<K>? comparer = null)
        {
            return (LowerBound(list, key, transform, comparer), UpperBound(list, key, transform, comparer));
        }

        public static (int LowerBound, int UpperBound) EqualRange<T>(this List<T> list, T key, IComparer<T>? comparer = null) 
        {
            return (LowerBound(list, key, comparer), UpperBound(list, key, comparer));
        }

        public static int LowerBound<T>(this List<T> list, T key, IComparer<T>? comparer = null)
        {
            return LowerBound(list, key, (T item) => item, comparer);
        }

        public static int UpperBound<T>(this List<T> list, T key, IComparer<T>? comparer = null)
        {
            return UpperBound(list, key, (T item) => item, comparer);
        }

        public static int LowerBound<T, K>(this List<T> list, K key, Func<T, K> transform, IComparer<K>? comparer = null)
        {
            Debug.Assert(list.IsSorted(transform, comparer));

            comparer ??= Comparer<K>.Default;

            //  Standard-Implementierung für "lowerBound"
            int begin = 0;
            int end = list.Count;
            int range = end - begin;
            while (range > 0)
            {
                int half = range / 2;
                if (comparer.Compare(transform(list[begin + half]), key) < 0)
                {
                    begin += ++half;
                    range -= half;
                }
                else
                {
                    range = half;
                }
            }
            return begin;
        }

        public static int UpperBound<T, K>(this List<T> list, K key, Func<T, K> transform, IComparer<K>? comparer = null)
        {
            Debug.Assert(list.IsSorted(transform, comparer));

            comparer ??= Comparer<K>.Default;

            //  Standard-Implementierung für "upperBound"
            int begin = 0;
            int end = list.Count;
            int range = end - begin;
            while (range > 0)
            {
                int half = range / 2;
                if (comparer.Compare(transform(list[begin + half]), key) >= 0)
                {
                    begin += ++half;
                    range -= half;
                }
                else
                {
                    range = half;
                }
            }
            return begin;
        }

        public static bool IsSorted<T>(this List<T> list, IComparer<T>? comparer = null)
        {            
            return IsSorted(list, (T item) => item, comparer);
        }

        public static bool IsSorted<T, K>(this List<T> list, Func<T, K> transform, IComparer<K>? comparer = null)
        {
            comparer ??= Comparer<K>.Default;

            for (int idx = 1; idx < list.Count; ++idx)
                if (comparer.Compare(transform(list[idx]), transform(list[idx - 1])) < 0)
                    return false;
            return true;
        }

        public static bool ReadYesNo(in string prompt)
        {
            Console.Write(prompt);
            var key = Console.ReadKey().Key;
            Console.WriteLine();
            return key == ConsoleKey.Y;
        }

        public static int ReadIntRequired(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                var line = Console.ReadLine();
                if (int.TryParse(line, out var value))
                    return value;
                Console.WriteLine("Bitte gültige ganze Zahl eingeben!");
            }
        }
    }
}
