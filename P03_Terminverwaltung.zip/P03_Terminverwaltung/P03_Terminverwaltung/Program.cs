﻿using static P03_Terminverwaltung.Utils;

namespace P03_Terminverwaltung
{
    //  Einfacher, menügesteuerter Kalender für die Textkonsole mit
    //  folgenden Features:
    //  - Termine mit 
    //    + Automatischer Id (nummerisch)
    //    + Titel
    //    + Startzeitpunkt (Datum und Uhrzeit)
    //    + Dauer (Minuten)
    //    + Ort
    //    + Beschreibung
    //    + Optionale Erinnerung mit einstellbarer Vorlaufzeit (Minuten)
    //  - Erstellung neuer Termine (mit eindeutigem Titel) [done]
    //  - Ändern von Terminen über den Titel [done]
    //  - Löschen von Terminen über den Titel [done]
    //  - Auflistung von Terminen mit optionalen Datumsfiltern [done]
    //  - Suche von Terminen über einfache Suchmuster [done]
    //  - JSON Export [done]
    //  - JSON Import [done]
    //  - Anzeige von Terminerinnerungen [done]
    internal class MyDates
    {
        static void Main(string[] args)
        {
            void create()
            {
                Console.WriteLine(Appointment.Create());
            }

            void edit()
            {
                Console.WriteLine(Appointment.Get(ReadIntRequired("Id des zu bearbeitenden Termins: "))?.Edit());
            }

            void delete()
            {
                Appointment.Delete(ReadIntRequired("Id des zu löschenden Termins: "));
            }

            void list()
            {
                Console.WriteLine("Auflistung aller Termine:");
                foreach (var appointment in Appointment.Get())
                    Console.WriteLine(appointment);
            }

            void listWeek()
            {
                //  !!!! Kalenderwoche bestimmen
                var week = (start: DateTime.Today, end: DateTime.Now + TimeSpan.FromDays(7));
                Console.WriteLine($"Termine in [{week.start.ToString("dd.MM.yyyy")} ... {week.end.ToString("dd.MM.yyyy")}[");
                foreach (var appointment in Appointment.Find(week.start, week.end))
                    Console.WriteLine(appointment);
            }

            void listMonth()
            {
                //  !!!! Kalendermonat bestimmen
                var month = (start: DateTime.Now, end: DateTime.Now + TimeSpan.FromDays(30));
                Console.WriteLine($"Termine in [{month.start.ToString("dd.MM.yyyy")}... {month.end.ToString("dd.MM.yyyy")}[");
                foreach (var appointment in Appointment.Find(month.start, month.end))
                    Console.WriteLine(appointment);
            }

            void search()
            {
                var pattern = Appointment.ReadLine("Suchmuster: ");
                Console.WriteLine($"Termine zum Suchmuster '{pattern}':");
                foreach (var appointment in Appointment.Find(pattern, true))
                    Console.WriteLine(appointment);
            }

            //const string jsonPath = "C:\\Users\\Teilnehmer-KW16-2024\\source\\repos\\P03_Terminverwaltung\\Appointments.json";
            const string jsonPath = "..\\..\\..\\..\\Appointments.json";
            void export()
            {
                try
                {
                    if (ReadYesNo("Exportierte JSON-Termine wirklich mit aktuellen Terminen überschreiben? [y/N]"))
                    {
                        var backupPath = jsonPath + ".bak";
                        if (File.Exists(backupPath))
                            File.Delete(backupPath);
                        File.Copy(jsonPath, jsonPath + ".bak");
                        File.WriteAllText(jsonPath, Appointment.ExportJSON(ReadYesNo("Hübsches JSON? [y/N]")));
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine($"\nError: {ex.Message}\n");
                }
            }

            void import()
            {
                try 
                {
                    if (ReadYesNo("Vorhandene Termine wirklich mit Terminen aus JSON-Import ersetzen? [y/N]"))
                        Appointment.ImportJSON(File.ReadAllText(jsonPath));
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"\nError: {ex.Message}\n");
                }
            }

            var catchAll = true;
            while (ConsoleKey.X != RunMenu(
                "=== Hauptmenü ===", catchAll,
                new(() => Appointment.CheckReminders()),
                new(ConsoleKey.N, "Neuer Termin", create), // () => Console.WriteLine(Appointment.Create())
                new(ConsoleKey.B, "Termin bearbeiten", edit),
                new(ConsoleKey.L, "Termin löschen", delete),
                new(ConsoleKey.A, "Auflisten aller Termine", list),
                new(ConsoleKey.W, "Termine der Woche anzeigen", listWeek),
                new(ConsoleKey.M, "Termine des Monats anzeigen", listMonth),
                new(ConsoleKey.S, "Termine suchen", search),
                new(ConsoleKey.E, "Export zur JSON-Datei", export),
                new(ConsoleKey.I, "Import aus JSON Datei", import),
                new() /*new(ConsoleKey.X, "Beenden")*/ ))
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("-----------------");
                Console.ResetColor();
            }

            Console.WriteLine("Ende mit beliebiger Taste...");
            Console.ReadKey();
        }

        readonly struct MenuItemOld
        {
            public MenuItemOld(ConsoleKey key, string prompt, Action? action)
            {
                Key = key;
                Prompt = prompt;
                Action = action;
            }
            public MenuItemOld(ConsoleKey key, string prompt) : this(key, prompt, null) { }
            public MenuItemOld() : this(ConsoleKey.X, "Beenden", null) { }
            public readonly ConsoleKey Key;
            public readonly string Prompt;
            public readonly Action? Action;
        }

        //  Ein 'record' ist eigentlich sowas wie ein typedef/using/alias für ein Tupel...
        readonly record struct MenuItem(ConsoleKey Key, string Prompt, Action? Action)
        {
            public MenuItem(ConsoleKey key, string prompt) : this(key, prompt, null) { }
            public MenuItem() : this(ConsoleKey.X, "Beenden", null) { }
        }

        //  Um die Menü-Eingabeaufforderung nach 'Action.Invoke()' 
        //  wieder anzuzeigen, geben Sie true aus 'Action' zurück.
        readonly record struct PeriodicAction(Func< bool > Action, TimeSpan Period)
        {
            public PeriodicAction(Func<bool> action) : this(action, TimeSpan.FromSeconds(1)) { }
            public PeriodicAction() : this(() => false, TimeSpan.FromDays(365)) { }
        }

        static ConsoleKey RunMenu(string prompt,
                                  bool catchAll, 
                                  PeriodicAction? periodicAction, // etwa 50 ms Zeitauflösung
                                  params MenuItem[] menuItems)
        {

            var key2Item = new Dictionary<ConsoleKey, MenuItem>();
            foreach (var menuItem in menuItems)
            {
                if (key2Item.ContainsKey(menuItem.Key))
                    throw new InvalidOperationException($"ExecuteMenu: key {menuItem.Key} not unique");
                key2Item[menuItem.Key] = menuItem;
            }

            void Prompt()
            {
                Console.WriteLine(prompt);
                foreach (var menuItem in menuItems)
                    Console.WriteLine($"[{menuItem.Key}] {menuItem.Prompt}");
            }

            Prompt();
            var periodEnd = periodicAction is null ? DateTime.MaxValue : DateTime.Now + periodicAction.Value.Period;
            while (true)
            {
                ConsoleKey? PollKeyboard() 
                { 
                    while (true)
                    {
                        if (DateTime.Now >= periodEnd)
                        {
                            var periodic = periodicAction.GetValueOrDefault();
                            if (periodic.Action?.Invoke() ?? false)
                                Prompt();
                            periodEnd = DateTime.Now + periodic.Period;
                        }
                        if (Console.KeyAvailable)
                            return Console.ReadKey(true).Key;
                        Thread.Sleep(TimeSpan.FromMilliseconds(50));
                    }
                }

                if (PollKeyboard() is ConsoleKey key)
                {
                    if (key2Item.ContainsKey(key))
                    {
                        Console.WriteLine();
                        if (catchAll)
                        {
                            try
                            {
                                key2Item[key].Action?.Invoke();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"\nError: {ex.Message}\n");
                            }
                        }
                        else
                        {
                            key2Item[key].Action?.Invoke();
                        }
                        return key;
                    }
                }
                else 
                {
                    return ConsoleKey.None;
                }
            }
        }
    }
}
