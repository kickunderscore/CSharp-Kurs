﻿using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using static P03_Terminverwaltung.Utils;

namespace P03_Terminverwaltung
{
    internal class Appointment : IComparable<Appointment>
    {
        private Appointment(string title,
                            DateTime start,
                            int duration,
                            string location = "",
                            string description = "",
                            int? reminderLeadTime = null, 
                            bool reminded = false)
        {
            Id = ++nextId;
            Title = title;
            Start = start;
            Duration = duration;
            Location = location;
            Description = description;
            ReminderLeadTime = reminderLeadTime;
            Reminded = reminded;

            //  Für Exceptionsicherheit zum Schluss!
            pool.ById[Id] = this;
            pool.Sorted.Insert(pool.Sorted.LowerBound(this), this);
        }

        private int _Id;         // 'unique key' aber nur sekundär in Sortierung
        private DateTime _Start; // Primäre Sortierung
        private string _Title;
        private int _Duration;
        private string _Location;
        private string _Description;
        private int? _ReminderLeadTime;

        private static (Dictionary<int, Appointment> ById, List<Appointment> Sorted) pool
                     = (new Dictionary<int, Appointment>(), new List<Appointment>());
        private static int nextId = 0;

        int IComparable<Appointment>.CompareTo(Appointment? other)
        {
            if (other == null) return 1;
            return (Start, Id).CompareTo((other.Start, other.Id));
        }

        public int Id
        {
            get => _Id;
            private set
            {
                if (value == _Id)
                    return; // unchanged => noop

                if (pool.ById.ContainsKey(value))
                    throw new InvalidOperationException($"Der Termin '{value}' existiert bereits");

                _Id = value;
            }
        }

        public DateTime Start
        {
            get => _Start;
            set
            {
                //  Einschränkung mit JSON-Export/Import nicht mehr uneingeschränkt 
                //  sinnvoll und daher in die Methode zur Datumseingabe verschoben.
                //if (value < DateTime.Now + TimeSpan.FromMinutes(1))
                //    throw new InvalidOperationException("Der Start muss in der Zukunft liegen");
                _Start = value;
            }
        }

        public string Title
        {
            get => _Title;
            private set
            {
                if (SafeString(value).Length == 0)
                    throw new InvalidOperationException("Der Titel darf nicht leer sein");

                _Title = value;
            }
        }

        public int Duration
        {
            get => _Duration;
            set
            {
                if (value < 1)
                    throw new InvalidOperationException("Die Dauer muss mindestens eine Minute betragen");
                _Duration = value;
            }
        }

        public string Location
        {
            get => _Location;
            set => _Location = SafeString(value);
        }

        public string Description
        {
            get => _Description;
            set => _Description = SafeString(value);
        }

        public int? ReminderLeadTime
        {
            get => _ReminderLeadTime;
            set
            {
                if (value is null || value >= 0)
                    _ReminderLeadTime = value;
                else
                    throw new InvalidOperationException("Ungültiger Wert für Vorlaufzeit");
            }
        }

        public bool Reminded { get; private set; } = false;

        public static Appointment Create()
        {
            Console.WriteLine("=== Neuer Termin ===");
            var title = ReadLine("[*] Titel: ");
            var start = ReadDateTime("[*] Start [dd-MM-yyyy HH:mm]: ");
            var duration = ReadDuration("[*] Dauer [Minuten]: ", true, true).GetValueOrDefault();
            var location = ReadLine("[ ] Ort: ");
            var description = ReadLine("[ ] Beschreibung: ");
            var reminderLeadTime = ReadDuration("[ ] Erinnerung [Minuten]: ", false, false);
            return new Appointment(title, start, duration, location, description, reminderLeadTime);
        }

        public static bool Delete(int id)
        {
            var deleted = false;
            if (pool.ById.ContainsKey(id))
            {
                if (ReadYesNo($"Termin {id} wirklich löschten? [y/N]"))
                {
                    Console.WriteLine($"Termin {id} wird gelöscht!");
                    pool.Sorted.RemoveAt(pool.Sorted.BinarySearch(pool.ById[id]));
                    pool.ById.Remove(id);
                    deleted = true;
                }
            }
            else
            {
                Console.WriteLine($"Termin {id} nicht vorhanden!");
            }
            return deleted;
        }

        public static Appointment? Get(int id)
        {
            return pool.ById.ContainsKey(id) ? pool.ById[id] : null;
        }

        public static List<Appointment> Get()
        {
            return new List<Appointment>(pool.Sorted);
        }

        public static List<Appointment> Find(DateTime start, DateTime end)
        {
            if (start > end)
                throw new InvalidOperationException("'start' muss kleiner oder gleich 'end' sein");
            var range = pool.Sorted.RangeQuery(start, end, (Appointment appointment) => appointment.Start);
            return pool.Sorted.GetRange(range.Begin, range.End - range.Begin);
        }

        public static List<Appointment> Find(string pattern, bool full)
        {
            bool test(string text) => text.Contains(pattern, StringComparison.CurrentCultureIgnoreCase);
            var result = new List<Appointment>();
            foreach (Appointment appointment in pool.Sorted)
                if (test(appointment.Id.ToString())
                    || test(appointment.Title)
                    || (full && (test(appointment.Start.ToShortDateString())
                              || test(appointment.Start.ToLongDateString())
                              || test(appointment.Start.ToString("dd.MM.yyyy HH:mm"))
                              || test(appointment.Duration.ToString())
                              || test(appointment.Location)
                              || test(appointment.Description))))
                    //  Anfänger-Bug: Auf das IEnumerable.Append() mit Kopie reingefallen!
                    //  Inkonsistente Nomenklatur in MS-APIs ist sehr schade (vgl. StringBuilder.Append())
                    //  result.Append(appointment);
                    result.Add(appointment);
            return result;
        }

        //  returns true if appointment reminders have been displayed
        public static bool CheckReminders()
        {
            var result = false;
            var now = DateTime.Now;
            foreach (var appointmemt in pool.Sorted)
            {

                if (appointmemt.ReminderLeadTime is not null && !appointmemt.Reminded)
                {
                    var reminderLeadTime = TimeSpan.FromMinutes(appointmemt.ReminderLeadTime.GetValueOrDefault());
                    var formatLong = @"d\ \T\a\g\e\n\ \u\n\d\ hh\:mm\:ss";
                    var formatShort = @"hh\:mm\:ss";
                    if (now > appointmemt.Start)
                    {
                        appointmemt.Reminded = result = true;
                        var duration = now - appointmemt.Start;
                        Console.Beep();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\n*** Versäumter Termin ***");
                        Console.WriteLine($"Termin vor {duration.ToString(duration.Days > 0 ? formatLong : formatShort)} Stunden:");
                        Console.WriteLine(appointmemt);
                        Console.WriteLine("************************\n");
                        Console.ResetColor();
                    }
                    else if (now >= appointmemt.Start - reminderLeadTime)
                    {
                        appointmemt.Reminded = result = true;
                        var duration = appointmemt.Start - now;
                        Console.Beep();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("\n*** Terminerinnerung ***");
                        Console.WriteLine($"Termin in {duration.ToString(duration.Days > 0 ? formatLong : formatShort)} Stunden:");
                        Console.WriteLine(appointmemt);
                        Console.WriteLine("************************\n");
                        Console.ResetColor();
                    }
                }
            }
            return result;
        }

        public static string ExportJSON(bool indented)
        {
            // using:
            // Automatische Freigabe der Ressourcen des IDispose beim
            // Verlassen des Scope ("Externer Destruktor für Arme?!")
            using var stream = new MemoryStream();
            using var writer = new Utf8JsonWriter(stream, new JsonWriterOptions { Indented = indented });
            writer.WriteStartObject();
            writer.WriteStartArray("appointments");
            foreach (var appointment in pool.Sorted)
            {
                writer.WriteStartObject();
                // don't write Id
                writer.WriteString("start", appointment.Start.ToString("yyyy-MM-ddTHH:mm:ssK"));
                writer.WriteString("title", appointment.Title);
                writer.WriteNumber("duration", appointment.Duration);
                writer.WriteString("location", appointment.Location);
                writer.WriteString("description", appointment.Description);
                if (appointment.ReminderLeadTime is null)
                    writer.WriteNull("reminderLeadTime");
                else
                    writer.WriteNumber("reminderLeadTime", appointment.ReminderLeadTime.Value);
                writer.WriteBoolean("reminded", appointment.Reminded);
                writer.WriteEndObject();
            }
            writer.WriteEndArray();
            writer.WriteEndObject();
            writer.Flush();
            return Encoding.UTF8.GetString(stream.ToArray());
        }

        public static void ImportJSON(string jsonUtf8)
        {
            var bakPool = pool;
            var bakNextId = nextId;
            try
            {
                pool = (new Dictionary<int, Appointment>(), new List<Appointment>());
                bakNextId = 0;
                var root = JsonNode.Parse(jsonUtf8)!;
                var appointments = root["appointments"]!;
                foreach (var jsonAppointment in appointments.AsArray())
                {
                    Console.WriteLine(new Appointment(
                        jsonAppointment!["title"]!.GetValue<string>(),
                        jsonAppointment!["start"]!.GetValue<DateTime>(),
                        jsonAppointment!["duration"]!.GetValue<int>(),
                        jsonAppointment!["location"]!.GetValue<string>(),
                        jsonAppointment!["description"]!.GetValue<string>(),
                        jsonAppointment!["reminderLeadTime"]!.GetValue<int>(),
                        jsonAppointment!["reminded"]!.GetValue<bool>()));                    
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nError: {ex.Message}\n");
                pool = bakPool;
                nextId = bakNextId;
            }
        }

        public Appointment Edit()
        {
            Console.WriteLine("=== Termin {Id} ändern ===");
            if (ReadYesNo($"Titel '{Title}' ändern? [y/N]"))
                Title = ReadLine("[*] Titel: ");
            if (ReadYesNo($"Start {Start.ToString("dd.MM.yyyy HH:mm")} ändern? [y/N]"))
                Retarget(ReadDateTime("[*] Start [dd-MM-yyyy HH:mm]: "));
            if (ReadYesNo($"Dauer {Duration} Minuten ändern? [y/N]"))
                Duration = ReadDuration("[*] Dauer [Minuten]: ", true, true).GetValueOrDefault();
            if (ReadYesNo($"Ort '{Location}' ändern? [y/N]"))
                Location = ReadLine("[ ] Ort: ");
            if (ReadYesNo($"Beschreibung '{Location}' ändern? [y/N]"))
                Description = ReadLine("[ ] Beschreibung: ");
            if (ReadYesNo($"Erinnerung in Minuten '{ReminderLeadTime}' ändern? [y/N]"))
                ReminderLeadTime = ReadDuration("[ ] Erinnerung [Minuten]: ", false, false);
            return this;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append($"=== Termin '{Id}' ===\n");
            sb.Append($"Titel: {Title}\n");
            sb.Append($"Start: {Start.ToString("dd-MM-yyyy HH:mm")}\n");
            sb.Append($"Dauer: {Duration} Minuten\n");
            sb.Append($"Ort: {Location}\n");
            sb.Append($"Beschreibung: {Description}\n");
            sb.Append($"Erinnerung: {(ReminderLeadTime >= 0 ? $"{ReminderLeadTime} Minuten vor Start" : "keine")}\n");
            sb.Append($"Erinnerung ausgegeben: {(Reminded ? "ja" : "nein")}\n");
            return sb.ToString();
        }

        private void Retarget(in DateTime start)
        {
            if (start == Start)
                return; // noop
            Start = start;
            Reminded = Start < DateTime.Now;
            pool.Sorted.Sort();
        }

        private static string SafeString(in string? value)
        {
            return value is null ? string.Empty : value;
        }

        public static string ReadLine(in string prompt)
        {
            Console.Write(prompt);
            if (Console.ReadLine() is string line)
                return line;
            return string.Empty;
        }

        private static DateTime ReadDateTime(in string prompt)
        {
            while (true)
            {
                if (DateTime.TryParse(ReadLine(prompt), out var start)
                    && start >= DateTime.Now + TimeSpan.FromMinutes(1))
                    return new DateTime(start.Ticks, DateTimeKind.Local);
                Console.WriteLine("Ungültige Angabe für Datum und Zeit (Format oder nicht zukünftig!");
            }
        }

        private static int? ReadDuration(in string prompt, bool required, bool positive)
        {
            string error() => $"Ungültige Eingabe für {(positive ? "positive " : "")}Dauer!";
            while (true)
            {
                var line = ReadLine(prompt);
                if (int.TryParse(line, out var minutes))
                {
                    if (minutes >= 0 && (!positive || minutes > 0))
                        return minutes;
                    Console.WriteLine(error());
                    continue;
                }
                if (!required && line.Length == 0)
                    return null;
                Console.WriteLine(error());
            }
        }
    }
}
